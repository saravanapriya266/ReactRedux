const redux = require('redux');
const createStore = redux.createStore;
const combineReducer = redux.combineReducers;

//Actions consts
const BUY_CAKE = 'BUY_CAKE';
const BUY_ICECREAM = 'BUY_ICECREAM';

//Action generating Functions
function buyCake() {
    return {
        type: BUY_CAKE,
        info: 'First Action'
    }
}

function buyIceCream() {
    return {
        type: BUY_ICECREAM,
        info: 'Second Action'
    }
}

//Define state
const initialStateCake = {
    noOfCakes : 10,
} 

const initialStateIcecream = {
    noOfIcecream : 20
}

//Reducer
const reducerCake = (state=initialStateCake, action) => {
    switch(action.type){
        case BUY_CAKE:        
            return {
                ...state,
                noOfCakes:state.noOfCakes-1
            }
        default: return state;
    }
}

const reducerIcecream = (state = initialStateIcecream, action) => {
    switch(action.type) {
        case BUY_ICECREAM:
            return {
                ...state,
                noOfIcecream: state.noOfIcecream-1
            }
        default: return state;
    }
}

const rootReducer = combineReducer({
    cake: reducerCake,
    ice: reducerIcecream})

//multiple reducer
const store = createStore(rootReducer);

//Single reducer
//const store = createStore(reducer);

console.log("\n Initial State",store.getState());
const unsubscribe = store.subscribe(()=>console.log(store.getState()));
store.dispatch(buyCake());
store.dispatch(buyCake());
store.dispatch(buyCake());
store.dispatch(buyIceCream());
unsubscribe();

//Middleware
//async
//Thunk